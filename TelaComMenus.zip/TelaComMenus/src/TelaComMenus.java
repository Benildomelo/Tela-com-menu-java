
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class TelaComMenus extends JFrame implements ActionListener{

    // a barra de menu
    JMenuBar menuBar = new JMenuBar();
    // os menus da Janela
    JMenu mArq = new JMenu("Arquivo");
    JMenu mEdit = new JMenu("Editar");
    JMenu mConfig = new JMenu("Configurar");
    // os itens do menu da janela
    JMenuItem miNovo = new JMenuItem("Novo");
    JMenuItem miSair = new JMenuItem("Sair");
    JMenuItem miCopiar = new JMenuItem("Copiar");
    JMenuItem miColar = new JMenuItem("Colar");
    JMenuItem miCTexto = new JMenuItem("Texto");
    JMenuItem miCImg = new JMenuItem("Imagem");
    //Separador
    JSeparator mSep = new JSeparator();
    
    JTextArea areaTexto = new JTextArea("Texto...");
    JScrollPane scrollPane = new JScrollPane(areaTexto);
    
    // método construtor
    public TelaComMenus() {
        
        this.setBounds(100, 100, 250, 170);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setTitle("Menu");
        
        // adicionando a barra de menu na janela
        this.setJMenuBar(menuBar);
        
        // add text com barra de rolagem
        this.add(scrollPane);
        
        // adicionando os menus na barra de menus
        menuBar.add(mArq);
        menuBar.add(mEdit);
        // adicinando os elemenos do menu arquivo
        mArq.add(miNovo);
        mArq.add(miSair);
        // adicinando os elemenos do menu editar
        mEdit.add(miCopiar);
        mEdit.add(miColar);
        mEdit.add(mSep);
        mEdit.add(mConfig);
        // adicionando os elemenos do menu configurar
        mConfig.add(miCTexto);
        mConfig.add(miCImg);
        
        miSair.addActionListener(this);
        miColar.addActionListener(this);
        miCopiar.addActionListener(this);
                
    }

    // método principal
    public static void main(String[] args) {
        TelaComMenus tl = new TelaComMenus();
        tl.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
       if (e.getSource().equals(miSair)){
           System.exit(0);
       }
       
       if (e.getSource().equals(miColar)){
           areaTexto.paste();
       }
       
        if (e.getSource().equals(miCopiar)){
           areaTexto.copy();
       }
    }

}
